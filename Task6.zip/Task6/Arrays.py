

def arrays(arr):
    # complete this function
    # use numpy.a
    a=numpy.array(arr,float)
    a=numpy.flip(a)
    return a


