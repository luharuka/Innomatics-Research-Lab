import numpy as np
n,m = map(int, input().split(' '))
np.set_printoptions(sign=' ')
print(np.eye(n,m))
