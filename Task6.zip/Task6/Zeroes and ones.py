
import numpy as np
arr=input().split()
arr=np.array(arr,int)
print(np.zeros((arr),dtype=int))
print(np.ones((arr),dtype=int))


