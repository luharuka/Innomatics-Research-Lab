# Find Angle MBC

import math
ab = float(input())
bc = float(input())
print(str(int(round(math.degrees(math.atan(ab/bc)),0)))+'°')
